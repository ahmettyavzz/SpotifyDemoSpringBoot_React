package com.yavuzahmet.SpotifyDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpotifyDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
